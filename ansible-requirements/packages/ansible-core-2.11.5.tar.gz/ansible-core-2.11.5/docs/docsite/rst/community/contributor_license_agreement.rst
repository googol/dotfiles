.. _contributor_license_agreement:

******************************
Contributors License Agreement
******************************

By contributing you agree that these contributions are your own (or approved by your employer) and you grant a full, complete, irrevocable copyright license to all users and developers of the project, present and future, pursuant to the license of the project.
