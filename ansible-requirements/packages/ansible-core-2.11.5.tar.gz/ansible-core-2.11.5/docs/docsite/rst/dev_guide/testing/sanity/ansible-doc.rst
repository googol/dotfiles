ansible-doc
===========

Verifies that ``ansible-doc`` can parse module documentation on all supported Python versions.
